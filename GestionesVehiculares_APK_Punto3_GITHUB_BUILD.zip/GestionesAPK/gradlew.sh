#!/bin/sh
set -e
APP_HOME=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
WRAPPER_DIR="$HOME/.gradle/wrapper/dists/gradle-8.7-bin"
ZIP="$WRAPPER_DIR/gradle-8.7-bin.zip"
DIST="$WRAPPER_DIR/gradle-8.7"
if [ ! -x "$DIST/bin/gradle" ]; then
  mkdir -p "$WRAPPER_DIR"
  if [ ! -f "$ZIP" ]; then
    if command -v curl >/dev/null 2>&1; then curl -L --fail -o "$ZIP" https://services.gradle.org/distributions/gradle-8.7-bin.zip
    elif command -v wget >/dev/null 2>&1; then wget -O "$ZIP" https://services.gradle.org/distributions/gradle-8.7-bin.zip
    else echo "No se encontró curl ni wget" >&2; exit 1; fi
  fi
  rm -rf "$DIST.tmp"
  mkdir -p "$DIST.tmp"
  if command -v unzip >/dev/null 2>&1; then unzip -q "$ZIP" -d "$DIST.tmp"; else echo "Se necesita unzip" >&2; exit 1; fi
  mv "$DIST.tmp/gradle-8.7" "$DIST"
  rm -rf "$DIST.tmp"
fi
exec "$DIST/bin/gradle" "$@"
