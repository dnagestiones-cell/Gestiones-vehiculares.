GESTIONES VEHICULARES - PROYECTO ANDROID

Esta copia incluye el Gradle Wrapper configurado para Gradle 8.7.

Proyecto: GestionesVehiculares
Modulo: app
Namespace: com.cris.gestionesvehiculares
AGP: 8.6.1
compileSdk: 35
minSdk: 23
targetSdk: 35

Si el IDE móvil permite importar proyectos Gradle, abre esta carpeta raíz
(la que contiene settings.gradle, build.gradle y gradlew).

Tarea de compilación del APK de prueba:
./gradlew assembleDebug

El APK quedará en:
app/build/outputs/apk/debug/app-debug.apk

La aplicación conserva la versión Punto 3: gestiones, búsqueda, filtros,
estados, edición, eliminación y guardado local.
